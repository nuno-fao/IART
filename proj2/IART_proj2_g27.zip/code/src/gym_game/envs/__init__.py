from gym_game.envs.aquarium_env import *
from gym_game.envs.aquarium_2d import Aquarium2D